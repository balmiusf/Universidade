package JogoDoGalo;

//31626 - Andre Figueira
public class InvalidNodeException extends Exception {
	InvalidNodeException(){
		super();
	}
	
	InvalidNodeException(String s){
		super(s);
	}
}
